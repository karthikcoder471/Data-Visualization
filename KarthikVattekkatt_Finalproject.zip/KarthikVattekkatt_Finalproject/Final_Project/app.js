var app = angular.module('myApp', []);

const start = "https://restcountries.eu/rest/v2/name/";
const end = "?fullText=true";
const start_country = "https://restcountries.eu/rest/v2/all";

app.controller('countryCtrl', function($scope, $http) {

$scope.submitSearch = function (isValid){

$scope.searchHeader = "";
//Get the current date, don't let the user submit a year after that or a year before 1900

//If the data is valid...
//if (isValid){
	  //this url is the omdbapi with my key, the t command is designed to search the movie database and return a single movie based on the title
   // https://restcountries.eu/rest/v2/name/aruba?fullText=true
        $scope.urlsearch = start + $scope.search + end;
	  //we use angulars $http.get to return a promise after trying to GET data from our api query containing the user's search
	  $http.get($scope.urlsearch).then(function (response) {
      //myData refers to the json that is returned from the API
	  $scope.myData = response.data;
              
      $scope.imgcode = response.data[0].alpha2Code;
          
          callSVG();
callPop(response.data[0].population);
                 
  });
    
    
//}
};
    
});


 

